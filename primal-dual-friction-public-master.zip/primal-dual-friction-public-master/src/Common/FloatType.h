#pragma once
namespace FrictionFrenzy {
typedef double FloatType;
}
